package com.liceu.dungeon_server.model;

public interface RoomSide {
    String enter (Player player);

}
