package com.liceu.dungeon_server.model;

public class Coin implements Item{
    @Override
    public String toString() {
        return "Coin";
    }
}
