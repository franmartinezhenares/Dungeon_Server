package com.liceu.dungeon_server.model;

public interface Item {
}
